# XF-ResourceThreads
Automatically approves/deletes threads upon resource approval/deletion.
